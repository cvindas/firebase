# Vanilla Javascript & Firebase Firestore CRUD

This project is web application using HTML, CSS, Javascript and Firebase Firestore as a Realtime databaes, using modules and modern Javascript in the browser
