# Firebase CRUD
a web application using HTML, CSS, Javascript and Firebase as a Backend.
